<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <a class='btn btn-primary' href="<?php echo e(route('fuelquote.create')); ?>">Create Fuel quote</a>
            <div class="card">
                <div class="card-header"><?php echo e(__('List Fuel Quote')); ?></div>
               
                <?php if(session('messenger')): ?>
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      <?php echo e(session('messenger')); ?>   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                <?php endif; ?>

                 
                 <table class="table panel panel-default">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Fuel Name</th>
                                <th scope="col">Gallon request</th> 
                                <th scope="col">Suggest Price</th> 
                                <th scope="col">Total Amount Due</th> 
                                <th scope="col">Delivery date</th> 
                                <th scope="col">Address</th> 
                                <th scope="col" style='width:1%'>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $data['fuelquote']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td>
                                        <?php 
                                        //do 2 cái fuel của 2 ko tồn tại có thể do ko đúng fuelid, nó ko tìm thấy fuelid này bên bảng fuel nên nó báo lôi// do e sửa bị sai rồi
                                        if(isset($val->Fuel->fuel_name)) 
                                            echo $val->Fuel->fuel_name;
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo number_format($val->gallonrequest,2);?>
                                    </td>
                                    <td>
                                        <?php echo number_format($val->suggestprice,2);?>    
                                    </td>
                                    <td>
                                        <?php echo number_format($val->totalAmountDue,2);?>
                                    </td>
                                    <td><?php echo e($val->deliverydate); ?></td>
                                    <td><?php echo e($val->streetname); ?> <?php echo e($val->city); ?> <?php echo e($val->state); ?> <?php echo e($val->zipcode); ?></td>


                                     
                                    <td>
                                        <a href="<?php echo e(route('fuelquote.edit',[$val->quoteid])); ?>"><i class="material-icons">border_color</i></a>
                                        <a style='cursor: pointer;' onclick="deleteob(<?php echo e($val->quoteid); ?>)" ><i class="fa fa-trash"></i></a>

                                    </td>
                                </tr>
                                 <?php $i++; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($data['fuelquote']->render()); ?>

                 
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function deleteob(id){
        var r =confirm('Delete this information?');
        if(r){
            window.location="fuelquote/delete/"+id;
        }
    }
 

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files (x86)\Ampps\www\2020\Fuel5801\resources\views/backend/fuelquote/list.blade.php ENDPATH**/ ?>
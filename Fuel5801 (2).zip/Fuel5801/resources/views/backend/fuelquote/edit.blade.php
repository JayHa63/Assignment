@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('FUEL QUOTE') }}</div>
               
                @if(session('messenger'))
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      {{session('messenger')}}   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                @endif

                <div class="card-body">
                    <form   action="{{ route('fuelquote.update',[$data['fuelquote']->quoteid])}}"   accept-charset="UTF-8" method="POST" enctype="multipart/form-data">
                         {{ method_field('PUT') }}{{csrf_field()}}

                          <div class="form-group row">

                            <label for="fuel_id" class="col-md-4 col-form-label text-md-right">{{ __('SELECT FUEL') }}</label>

                            <div class="col-md-6">
                                <select onchange="capnhatprice()" id="fuel_id" name="fuel_id" class="form-control{{ $errors->has('fuel_id') ? ' is-invalid' : '' }}"  required >
                                    @if(count($data['fuels'])>1)
                                    <option value="">Choose...</option>
                                    @endif
                                    
                                    @foreach($data['fuels'] as $val)
                                    <option
                                    <?php
                                    //hiện tại nó chưa nhớ giá trị lúc chỉnh mình phải cho nó nhớ giá trị cũ
                                    if($data['fuelquote']['fuel_id']==$val->fuel_id) echo "selected";
                                    ?>
                                    value="{{$val->fuel_id}}">{{$val->fuel_name}}</option>
                                    <!-- dùng iput tạm để lưu price của fuel, có nhiều cách làm-->
                                    @endforeach
                                </select>
                                 @if ($errors->has('fuelid')) 
                                    <p class='plgalert'>{{ $errors->first('fuel_id') }}</p>
                                  @endif
                            </div>
                             @foreach($data['fuels'] as $val)
                             <input type="hidden" id="price{{$val->fuel_id}}" value='{{$val->fuel_price}}'/>
                             @endforeach
                          </div>

                        <div class="form-group row">
                            <label for="gallonrequest" class="col-md-4 col-form-label text-md-right">{{ __('Gallon Request') }}</label>

                            <div class="col-md-6">
                                <input id="gallonrequest" onkeyup="capnhatprice()" type="text" class="form-control @error('gallonrequest') is-invalid @enderror" name="gallonrequest" value="{{$data['fuelquote']['gallonrequest']}}" required autocomplete="gallonrequest" autofocus>

                                @error('gallonrequest')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="suggestprice" class="col-md-4 col-form-label text-md-right">{{ __('Suggest Price') }}</label>

                            <div class="col-md-6">
                                <input id="suggestprice" type="text" class="form-control @error('suggestprice') is-invalid @enderror" name="suggestprice" value="{{$data['fuelquote']['suggestprice']}}" required autocomplete="suggestprice" autofocus>

                                @error('suggestprice')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="totalAmountDue" class="col-md-4 col-form-label text-md-right">{{ __('Total Amount Due') }}</label>

                            <div class="col-md-6">
                                <input id="totalAmountDue" type="text" class="form-control @error('totalAmountDue') is-invalid @enderror" name="totalAmountDue" value="{{$data['fuelquote']['totalAmountDue']}}" required autocomplete="totalAmountDue" autofocus>

                                @error('totalAmountDue')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="deliverydate" class="col-md-4 col-form-label text-md-right">{{ __('Delivery Date') }}</label>

                            <div class="col-md-6">
                                <input id="deliverydate" type="date" class="form-control @error('deliverydate') is-invalid @enderror" name="deliverydate" value="{{$data['fuelquote']['deliverydate']}}" required autocomplete="deliverydate" autofocus>

                                @error('deliverydate')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="streetname" class="col-md-4 col-form-label text-md-right">{{ __('Street name') }}</label>

                            <div class="col-md-6">
                                <input id="streetname" type="text" class="form-control @error('streetname') is-invalid @enderror" name="streetname" value="{{$data['fuelquote']['streetname']}}" required autocomplete="streetname" autofocus>

                                @error('streetname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right">{{ __('City') }}</label>

                            <div class="col-md-6">
                                <input id="city" type="text" class="form-control @error('city') is-invalid @enderror" name="city" value="{{$data['fuelquote']['city']}}" required autocomplete="city" autofocus>

                                @error('city')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="state" class="col-md-4 col-form-label text-md-right">{{ __('State') }}</label>

                            <div class="col-md-6">
                                <input id="state" type="text" class="form-control @error('state') is-invalid @enderror" name="state" value="{{$data['fuelquote']['state']}}" required autocomplete="state" autofocus>

                                @error('state')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zipcode" class="col-md-4 col-form-label text-md-right">{{ __('Zipcode') }}</label>

                            <div class="col-md-6">
                                <input id="zipcode" type="text" class="form-control @error('zipcode') is-invalid @enderror" name="zipcode" value="{{$data['fuelquote']['zipcode']}}" required autocomplete="zipcode" autofocus>

                                @error('zipcode')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Save') }}
                                </button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function capnhatprice(){
        //alert($("#fuel_id").val());
        //alert($("#gallonrequest").val());
        var idprice="#price"+$("#fuel_id").val();
        //alert($(idprice).val());
        $("#suggestprice").val($(idprice).val());
        $("#totalAmountDue").val($(idprice).val()*$("#gallonrequest").val());
        //suggestprice
        //totalAmountDue

    }
</script>
@endsection
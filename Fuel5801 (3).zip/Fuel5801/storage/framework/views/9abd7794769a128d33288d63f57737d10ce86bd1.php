<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('CREATE FUEL QUOTE')); ?></div>
               
                <?php if(session('messenger')): ?>
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      <?php echo e(session('messenger')); ?>   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                <?php endif; ?>

                <div class="card-body">
                    <form   action="<?php echo e(route('fuelquote.store')); ?>"   accept-charset="UTF-8" method="POST" enctype="multipart/form-data">
                         <?php echo csrf_field(); ?>
                    
                          <div class="form-group row">

                            <label for="fuel_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('SELECT FUEL')); ?></label>

                            <div class="col-md-6">
                                


                                <select id="fuel_id" onchange="capnhatprice()"  name="fuel_id" class="form-control<?php echo e($errors->has('fuel_id') ? ' is-invalid' : ''); ?>"  required >

                                    <?php if(count($data['fuels'])>1): ?>
                                        <option value="">Choose...</option>
                                    <?php endif; ?>

                                    <?php $__currentLoopData = $data['fuels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->fuel_id); ?>"><?php echo e($val->fuel_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>



                                 <?php if($errors->has('fuelid')): ?> 
                                    <p class='plgalert'><?php echo e($errors->first('fuel_id')); ?></p>
                                  <?php endif; ?>
                            </div>
                            <?php $__currentLoopData = $data['fuels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <input type="hidden" id="price<?php echo e($val->fuel_id); ?>" value='<?php echo e($val->fuel_price); ?>'/>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>

                         <div class="form-group row">
                            <label for="gallonrequest"  class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gallon Request')); ?></label>

                            <div class="col-md-6">
                                <input id="gallonrequest" onkeyup="capnhatprice()"  type="text" class="form-control <?php if ($errors->has('gallonrequest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gallonrequest'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gallonrequest" value="<?php echo e($data['fuelquote']['gallonrequest']); ?>" required autocomplete="gallonrequest" autofocus>

                                <?php if ($errors->has('gallonrequest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gallonrequest'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                         
                         <div class="form-group row">
                            <label for="deliverydate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Delivery Date')); ?></label>

                            <div class="col-md-6">
                                <input id="deliverydate" type="date" class="form-control <?php if ($errors->has('deliverydate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deliverydate'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="deliverydate" value="<?php echo e($data['fuelquote']['deliverydate']); ?>" required autocomplete="deliverydate" autofocus>

                                <?php if ($errors->has('deliverydate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deliverydate'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="deliverydate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Street Name')); ?></label>

                            <div class="col-md-6">
                                <input disabled id="streetname" type="text" class="form-control <?php if ($errors->has('streetname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('streetname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="streetname" value="<?php echo e($data['fuelquote']['streetname']); ?>" required autocomplete="streetname" autofocus>

                                <?php if ($errors->has('streetname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('streetname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City')); ?></label>

                            <div class="col-md-6">
                                <input disabled id="city" type="text" class="form-control <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="city" value="<?php echo e($data['fuelquote']['city']); ?>" required autocomplete="city" autofocus>

                                <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="state" class="col-md-4 col-form-label text-md-right"><?php echo e(__('State')); ?></label>

                            <div class="col-md-6">
                                
                                <?php
                                $state=array('Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming');
                                ?>
                                <select  disabled onchange="capnhatprice()" id="state" type="text" class="form-control <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="state" value="<?php echo e($data['fuelquote']['state']); ?>" required autocomplete="state" autofocus>
                                    <?php foreach($state as $val){ ?>
                                    <option value="<?php echo e($val); ?>"
                                    <?php if($val==$data['fuelquote']['state']) echo "selected"; ?>
                                    ><?php echo e($val); ?></option>
                                    <?php } ?>
                                    
                                </select>

                                <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zipcode" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Zipcode')); ?></label>

                            <div class="col-md-6">
                                <input disabled id="zipcode" type="text" class="form-control <?php if ($errors->has('zipcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zipcode'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="zipcode" value="<?php echo e($data['fuelquote']['zipcode']); ?>" required autocomplete="zipcode" autofocus>

                                <?php if ($errors->has('zipcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zipcode'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="suggestprice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Suggest Price')); ?>($)</label>

                            <div class="col-md-6">
                                <input disabled id="suggestprice" type="text" class="form-control <?php if ($errors->has('suggestprice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('suggestprice'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="suggestprice" value="<?php echo e($data['fuelquote']['suggestprice']); ?>" required autocomplete="suggestprice" autofocus>

                                <?php if ($errors->has('suggestprice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('suggestprice'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        
                         <div class="form-group row">
                            <label for="totalAmountDue" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total Amount Due')); ?>($)</label>

                            <div class="col-md-6">
                                <input id='buy' type="hidden" value="<?php echo e($data['buy']); ?>" />
                                <input disabled id="totalAmountDue" type="text" class="form-control <?php if ($errors->has('totalAmountDue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalAmountDue'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="totalAmountDue" value="<?php echo e($data['fuelquote']['totalAmountDue']); ?>" required autocomplete="totalAmountDue" autofocus>

                                <?php if ($errors->has('totalAmountDue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalAmountDue'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function capnhatprice(){
        //alert($("#state").val());
        // alert($("#fuel_id").val());
       // alert($("#gallonrequest").val());
        //suggestedprice/1 gallon=1.50+[0.02(0.04)-0.01(0)+0.02(0.03)+0.1+0.04(0.03)]*price_fuel



        var pstate,pmonth=0,pgalon,sgprice;
        if($("#state").val()=="Texas") pstate=0.02;
        else  pstate=0.04;

        console.log("pstate"+pstate);
        //------$("#buy").val()
        var d = new Date();
        if(d.getMonth()>=3 && d.getMonth()<=5) pmonth=0.04;
        else pmonth=0.03;


        if($("#gallonrequest").val()>=1000) pgalon=0.02;
        else pgalon=0.03;
        //-------
        sgprice=1.5+(pstate-$("#buy").val()+pgalon+0.1+pmonth)*1.5;
        sgprice=sgprice.toFixed(2);
        
        if(pmonth>0 && $("#gallonrequest").val()>0){
            $("#suggestprice").val(sgprice);
            $("#totalAmountDue").val(sgprice*$("#gallonrequest").val());
        }

        //suggestprice
        //totalAmountDue

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files (x86)\Ampps\www\2020\Fuel5801\resources\views/backend/fuelquote/add.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('FUEL QUOTE')); ?></div>
               
                <?php if(session('messenger')): ?>
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      <?php echo e(session('messenger')); ?>   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                <?php endif; ?>

                <div class="card-body">
                    <form   action="<?php echo e(route('fuelquote.update',[$data['fuelquote']->quoteid])); ?>"   accept-charset="UTF-8" method="POST" enctype="multipart/form-data">
                         <?php echo e(method_field('PUT')); ?><?php echo e(csrf_field()); ?>


                          <div class="form-group row">

                            <label for="fuel_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('SELECT FUEL')); ?></label>

                            <div class="col-md-6">
                                <select id="fuel_id" name="fuel_id" class="form-control<?php echo e($errors->has('fuel_id') ? ' is-invalid' : ''); ?>"  required >
                                    <?php if(count($data['fuels'])>1): ?>
                                    <option value="">Choose...</option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $data['fuels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->fuel_id); ?>"><?php echo e($val->fuel_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                 <?php if($errors->has('fuelid')): ?> 
                                    <p class='plgalert'><?php echo e($errors->first('fuel_id')); ?></p>
                                  <?php endif; ?>
                            </div>

                          </div>

                        <div class="form-group row">
                            <label for="gallonrequest" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gallon Request')); ?></label>

                            <div class="col-md-6">
                                <input id="gallonrequest" type="text" class="form-control <?php if ($errors->has('gallonrequest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gallonrequest'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gallonrequest" value="<?php echo e($data['fuelquote']['gallonrequest']); ?>" required autocomplete="gallonrequest" autofocus>

                                <?php if ($errors->has('gallonrequest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gallonrequest'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="suggestprice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Suggest Price')); ?></label>

                            <div class="col-md-6">
                                <input id="suggestprice" type="text" class="form-control <?php if ($errors->has('suggestprice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('suggestprice'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="suggestprice" value="<?php echo e($data['fuelquote']['suggestprice']); ?>" required autocomplete="suggestprice" autofocus>

                                <?php if ($errors->has('suggestprice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('suggestprice'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="totalAmountDue" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total Amount Due')); ?></label>

                            <div class="col-md-6">
                                <input id="totalAmountDue" type="text" class="form-control <?php if ($errors->has('totalAmountDue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalAmountDue'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="totalAmountDue" value="<?php echo e($data['fuelquote']['totalAmountDue']); ?>" required autocomplete="totalAmountDue" autofocus>

                                <?php if ($errors->has('totalAmountDue')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('totalAmountDue'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="deliverydate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Delivery Date')); ?></label>

                            <div class="col-md-6">
                                <input id="deliverydate" type="date" class="form-control <?php if ($errors->has('deliverydate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deliverydate'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="deliverydate" value="<?php echo e($data['fuelquote']['deliverydate']); ?>" required autocomplete="deliverydate" autofocus>

                                <?php if ($errors->has('deliverydate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deliverydate'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files (x86)\Ampps\www\2020\Fuel5801\resources\views/backend/fuelquote/edit.blade.php ENDPATH**/ ?>
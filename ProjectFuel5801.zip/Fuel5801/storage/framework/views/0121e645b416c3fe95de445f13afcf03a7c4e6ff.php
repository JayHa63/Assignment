<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <a class='btn btn-primary' href="<?php echo e(route('fuel.create')); ?>">Create Fuel</a>
            <div class="card">
                <div class="card-header"><?php echo e(__('List Fuel')); ?></div>
               
                <?php if(session('messenger')): ?>
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      <?php echo e(session('messenger')); ?>   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                <?php endif; ?>

                

                 
                 <table class="table panel panel-default">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Price</th> 
                                <th scope="col">Location</th> 
                                <th scope="col" style='width:1%'>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $data['fuels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($val->fuel_name); ?></td>
                                    <td><?php echo e($val->fuel_price); ?></td>
                                    <td><?php echo e($val->location); ?></td>
                                     
                                    <td>
                                        <a href="<?php echo e(route('fuel.edit',[$val->fuel_id])); ?>"><i class="material-icons">border_color</i></a>

                                        <a style='cursor: pointer;' onclick="deleteob(<?php echo e($val->fuel_id); ?>)" >DL</a>
                                    </td>
                                </tr>
                                 <?php $i++; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($data['fuels']->render()); ?>

                 
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function deleteob(id){
        var r =confirm('Delete this information?');
        if(r){
            window.location="fuel/delete/"+id;
        }
    }
 

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files (x86)\Ampps\www\2020\Fuel5801\resources\views/backend/fuel/list.blade.php ENDPATH**/ ?>
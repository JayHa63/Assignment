<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('EDIT Fuel')); ?></div>
               
                <?php if(session('messenger')): ?>
                    <div class="alert alert-success"><i class="fa fa-check-circle"></i>    
                      <?php echo e(session('messenger')); ?>   <button type="button" class="close" data-dismiss="alert">×</button>
                        </div>
                <?php endif; ?>

                <div class="card-body">
                    <form   action="<?php echo e(route('fuel.update',[$data['fuel']->fuel_id])); ?>"   accept-charset="UTF-8" method="POST" enctype="multipart/form-data">
                         <?php echo e(method_field('PUT')); ?><?php echo e(csrf_field()); ?>


                        <div class="form-group row">
                            <label for="fuel_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fuelname')); ?></label>

                            <div class="col-md-6">
                                <input id="fuel_name" type="text" class="form-control <?php if ($errors->has('fuel_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fuel_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fuel_name" value="<?php echo e($data['fuel']['fuel_name']); ?>" required autocomplete="fuel_name" autofocus>

                                <?php if ($errors->has('fuel_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fuel_name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fuel_price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Price')); ?></label>

                            <div class="col-md-6">
                                <input id="fuel_price" type="text" class="form-control <?php if ($errors->has('fuel_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fuel_price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fuel_price" value="<?php echo e($data['fuel']['fuel_price']); ?>" required autocomplete="fuel_price" autofocus>

                                <?php if ($errors->has('fuel_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fuel_price'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Location')); ?></label>

                            <div class="col-md-6">
                                <input id="location" type="text" class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="location" value="<?php echo e($data['fuel']['location']); ?>" required autocomplete="location" autofocus>

                                <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>



                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    
    
    $(document).ready(function(){
      $("#fuel_price").keypress(function(){
         var str=$("#fuel_price").val()// lay gai trị input 
         var res = str.replace("$", "");// bỏ dau $
         $("#fuel_price").val("$"+res);
      });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files (x86)\Ampps\www\2020\Fuel5801\resources\views/backend/fuel/edit.blade.php ENDPATH**/ ?>